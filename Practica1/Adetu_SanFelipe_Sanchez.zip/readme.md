Laurentiu Mihai Adetu
Adrian San Felipe Martin
Sergio Sanchez Alcalde