
#ifndef _CALC_H_

struct _info_atributos {
	char id;
	int valor;
};
typedef struct _info_atributos info_atributos;

#endif

