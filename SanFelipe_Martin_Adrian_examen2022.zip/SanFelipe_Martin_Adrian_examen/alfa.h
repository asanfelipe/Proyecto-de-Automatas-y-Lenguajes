#ifndef ALFA_H
#define ALFA_H
#define MAX_LONG_ID 100
#define MAX_TAMANIO_VECTOR 64

#include "generacion.h"
#include "tabla_simbolos.h"


typedef struct _tipo_atributos {
 char lex[MAX_LONG_ID+1];
 int tipo;
 int valor;
 int es_dir;
 int etiqueta;
 char ind_lex[MAX_LONG_ID+1];
 int ind_is_dir;
} tipo_atributos;

#endif /* ALFA_H */
