#include "tabla_hash.h"


typedef struct _tablasSimbolos {
  TABLA_HASH *hash_global;
  TABLA_HASH *hash_local;
  int is_local;
} TABLAS_HASH;


int cerrarAmbito(TABLAS_HASH *hashTable);
int insertTabla(TABLAS_HASH *hashTable, char *key, SIMBOLO *valor);
SIMBOLO *findTabla(TABLAS_HASH *hashTable, char *key);