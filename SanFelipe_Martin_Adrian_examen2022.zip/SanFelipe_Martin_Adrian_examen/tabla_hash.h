#define _XOPEN_SOURCE 500

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>

#define VARIABLE 0
#define PARAMETRO 1
#define FUNCION 2
#define ENTERO 1
#define BOOLEANO 0
#define ESCALAR 0
#define VECTOR 1
#define CHAR_TAM 128

typedef struct _simbolo
{
    char identificador[128];
    int symbol;
    int tipo;
    int categoria;
    int valor;
    int longitud;
    int num_parametros;
    int posicion;
    int num_loc;
} SIMBOLO;

typedef struct _NODO NODO;

typedef struct _TABLA_HASH TABLA_HASH;

TABLA_HASH *tablahash_init(int size);
int tablahash_hash(TABLA_HASH *hashtable, char *key);
NODO *tablahash_newpair(char *key, SIMBOLO *value);
int tablahash_set(TABLA_HASH *hashtable, char *key, SIMBOLO *value);
SIMBOLO *tablahash_get(TABLA_HASH *hashtable, char *key);
SIMBOLO *nuevo_simbolo(char *identificador, int symbol, int tipo, int categoria, int valor, int longitud, int num_parametros, int posicion, int num_loc);