#include "generacion.h"

void escribir_cabecera_bss(FILE *fpasm){
  if (fpasm == NULL){
    fprintf(stderr, "escribir cabecera\n");
    return;
  }
  fprintf(fpasm, "segment .bss\n");
  fprintf(fpasm, "\t__esp resd 1\n");
  return;
}

void escribir_subseccion_data(FILE *fpasm)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "escribir subseccion data\n");
    return;
  }
  fprintf(fpasm, "segment .data\n");
  fprintf(fpasm, "\tmsg_error_indice_vector db \"Indice de vector fuera de rango\", 0\n");
  fprintf(fpasm, "\tmsg_error_division db \"Error division por 0\", 0\n");
  fprintf(fpasm, "\tmsg_error_potencia db \"Error potencia negativa\", 0\n");
}

void declarar_variable(FILE *fpasm, char *nombre, int tipo, int tamano)
{
  if (fpasm == NULL || !nombre)
  {
    fprintf(stderr, "declarar variable\n");
    return;
  }

  fprintf(fpasm, "\t_%s ", nombre);
  if (tipo == ENTERO || tipo == BOOLEANO)
    fprintf(fpasm, "resd ");

  fprintf(fpasm, "%d", tamano);
  fprintf(fpasm, "\n");
  return;
}

void escribir_segmento_codigo(FILE *fpasm)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "escribir_segmento_codigo\n");
    return;
  }

  fprintf(fpasm, "segment .text\n");
  fprintf(fpasm, "global main\n");
  fprintf(fpasm, "\textern malloc, free\n");
  fprintf(fpasm, "\textern scan_int, print_int, scan_boolean, print_boolean\n");
  fprintf(fpasm, "\textern print_endofline, print_blank, print_string\n");
}

void escribir_inicio_main(FILE *fpasm)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "escribir_inicio_main\n");
    return;
  }
  fprintf(fpasm, "%s", "main:\n");
  fprintf(fpasm, "%s", "\tmov dword [__esp], esp\n");
}

void escribir_fin(FILE *fpasm)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "escribir_fin\n");
    return;
  }
  fprintf(fpasm, "\tjmp near fin\n");

  //Error division por 0
  fprintf(fpasm, "fin_error_division:\n");
  fprintf(fpasm, "\tpush dword msg_error_division\n");
  fprintf(fpasm, "\tcall print_string\n");
  fprintf(fpasm, "\tadd esp, 4\n");
  fprintf(fpasm, "\tcall print_endofline\n");
  fprintf(fpasm, "\tjmp near fin\n");

  //Error indice fuera rango
  fprintf(fpasm, "fin_indice_fuera_rango:\n");
  fprintf(fpasm, "\tpush dword msg_error_indice_vector\n");
  fprintf(fpasm, "\tcall print_string\n");
  fprintf(fpasm, "\tadd esp, 4\n");
  fprintf(fpasm, "\tcall print_endofline\n");
  fprintf(fpasm, "\tjmp near fin\n");

  //Error potencia
  fprintf(fpasm, "print_error_pow:\n");
  fprintf(fpasm, "\tpush dword msg_error_potencia\n");
  fprintf(fpasm, "\tcall print_string\n");
  fprintf(fpasm, "\tadd esp, 4\n");
  fprintf(fpasm, "\tcall print_endofline\n");

  // FIN
  fprintf(fpasm, "fin:\n");
  fprintf(fpasm, "\tmov esp, [__esp]\n");
  fprintf(fpasm, "\tret\n");
}

void asignar(FILE *fpasm, char *nombre, int es_variable)
{
  if (fpasm == NULL || !nombre || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "asignar\n");
    return;
  }

  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable == 1)
    fprintf(fpasm, "\tmov dword _%s, eax\n", nombre);
  else
    fprintf(fpasm, "\tmov dword [_%s], eax\n", nombre);
}

void sumar(FILE *fpasm, int es_variable_1, int es_variable_2)
{
  if (fpasm == NULL || (es_variable_1 != 0 && es_variable_1 != 1) || (es_variable_2 != 0 && es_variable_2 != 1))
  {
    fprintf(stderr, "sumar\n");
    return;
  }
  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_variable_1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  if (es_variable_2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tadd eax, edx\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void restar(FILE *fpasm, int es_variable_1, int es_variable_2)
{
  if (fpasm == NULL || (es_variable_1 != 0 && es_variable_1 != 1) || (es_variable_2 != 0 && es_variable_2 != 1))
  {
    fprintf(stderr, "sumar\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_variable_1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  if (es_variable_2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "sub eax, edx\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void dividir(FILE *fpasm, int es_variable1, int es_variable2)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "dividir\n");
    return;
  }

  fprintf(fpasm, "\tpop dword ecx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  if (es_variable2)
    fprintf(fpasm, "\tmov dword ecx, [ecx]\n");

  fprintf(fpasm, "\tcmp ecx, 0\n");
  fprintf(fpasm, "\tje fin_error_division\n");
  fprintf(fpasm, "\tcdq\n");
  fprintf(fpasm, "\tidiv dword ecx\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void multiplicar(FILE *fpasm, int es_variable1, int es_variable2)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "multiplicar\n");
    return;
  }
  fprintf(fpasm, "\tpop dword ecx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword ecx, [ecx]\n");

  fprintf(fpasm, "\timul ecx\n");
  fprintf(fpasm, "\tcdq\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void o(FILE *fpasm, int es_variable_1, int es_variable_2)
{
  if (fpasm == NULL || (es_variable_1 != 0 && es_variable_1 != 1) || (es_variable_2 != 0 && es_variable_2 != 1))
  {
    fprintf(stderr, "o\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable_1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  if (es_variable_2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tor eax, edx\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void y(FILE *fpasm, int es_variable_1, int es_variable_2)
{
  if (fpasm == NULL || (es_variable_1 != 0 && es_variable_1 != 1) || (es_variable_2 != 0 && es_variable_2 != 1))
  {
    fprintf(stderr, "y\n");
    return;
  }
  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable_1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  if (es_variable_2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tand eax, edx\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void cambiar_signo(FILE *fpasm, int es_variable)
{
  if (fpasm == NULL || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "cambiar_signo\n");
    return;
  }

  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  fprintf(fpasm, "\tneg eax\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void no(FILE *fpasm, int es_variable, int cuantos_no)
{
  if (fpasm == NULL || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "no\n");
    return;
  }
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_variable)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  fprintf(fpasm, "\tor eax, eax\n");
  fprintf(fpasm, "\tjz near negar_falso%d\n", cuantos_no);
  fprintf(fpasm, "\tmov dword eax, 0\n");
  fprintf(fpasm, "\tjmp near fin_negacion%d\n", cuantos_no);
  fprintf(fpasm, "negar_falso%d:\n", cuantos_no);
  fprintf(fpasm, "\tmov dword eax, 1\n");
  fprintf(fpasm, "fin_negacion%d:\n", cuantos_no);
  fprintf(fpasm, "\tpush dword eax\n");
}

void igual(FILE *fpasm, int es_variable1, int es_variable2, int etiqueta)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "igual\n");
    return;
  }

  fprintf(fpasm, "\tpop dword ebx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword ebx, [ebx]\n");

  fprintf(fpasm, "\tcmp dword eax, ebx\n");
  fprintf(fpasm, "\tje near igual%d\n", etiqueta);
  fprintf(fpasm, "\tpush dword 0\n");
  fprintf(fpasm, "\tjmp near fin_igual%d\n", etiqueta);
  fprintf(fpasm, "igual%d:\n", etiqueta);
  fprintf(fpasm, "\tpush dword 1\n");
  fprintf(fpasm, "fin_igual%d:\n", etiqueta);
}

void distinto(FILE *fpasm, int es_variable1, int es_variable2, int etiqueta)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "distinto\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tcmp dword eax, edx\n");
  fprintf(fpasm, "\tjne near distinto%d\n", etiqueta);
  fprintf(fpasm, "\tpush dword 0\n");
  fprintf(fpasm, "\tjmp near fin_distinto%d\n", etiqueta);
  fprintf(fpasm, "distinto%d:\n", etiqueta);
  fprintf(fpasm, "\tpush dword 1\n");
  fprintf(fpasm, "fin_distinto%d:\n", etiqueta);
}

void menor_igual(FILE *fpasm, int es_variable1, int es_variable2, int etiqueta)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "menorigual\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tcmp dword eax, edx\n");
  fprintf(fpasm, "\tjle near menorigual%d\n", etiqueta);
  fprintf(fpasm, "\tpush dword 0\n");
  fprintf(fpasm, "\tjmp near fin_menorigual%d\n", etiqueta);
  fprintf(fpasm, "\tmenorigual%d:\n", etiqueta);
  fprintf(fpasm, "\tpush dword 1\n");
  fprintf(fpasm, "fin_menorigual%d:\n", etiqueta);
}

void mayor_igual(FILE *fpasm, int es_variable1, int es_variable2, int etiqueta)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "mayorigual\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tcmp dword eax, edx\n");
  fprintf(fpasm, "\tjge near mayorigual%d\n", etiqueta);
  fprintf(fpasm, "\tpush dword 0\n");
  fprintf(fpasm, "\tjmp near fin_mayorigual%d\n", etiqueta);
  fprintf(fpasm, "mayorigual%d:\n", etiqueta);
  fprintf(fpasm, "\tpush dword 1\n");
  fprintf(fpasm, "fin_mayorigual%d:\n", etiqueta);
}

void menor(FILE *fpasm, int es_variable1, int es_variable2, int etiqueta)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "menor\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tcmp dword eax, edx\n");
  fprintf(fpasm, "\tjl near si_menor%d\n", etiqueta);
  fprintf(fpasm, "\tpush dword 0\n");
  fprintf(fpasm, "\tjmp near fin_menor%d\n", etiqueta);
  fprintf(fpasm, "si_menor%d:\n", etiqueta);
  fprintf(fpasm, "\tpush dword 1\n");
  fprintf(fpasm, "fin_menor%d:\n", etiqueta);
}

void mayor(FILE *fpasm, int es_variable1, int es_variable2, int etiqueta)
{
  if (fpasm == NULL || (es_variable1 != 0 && es_variable1 != 1) || (es_variable2 != 0 && es_variable2 != 1))
  {
    fprintf(stderr, "mayor\n");
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  if (es_variable2)
    fprintf(fpasm, "\tmov dword edx, [edx]\n");

  fprintf(fpasm, "\tcmp dword eax, edx\n");
  fprintf(fpasm, "\tjg near si_mayor%d\n", etiqueta);
  fprintf(fpasm, "\tpush dword 0\n");
  fprintf(fpasm, "\tjmp near fin_mayor%d\n", etiqueta);
  fprintf(fpasm, "si_mayor%d:\n", etiqueta);
  fprintf(fpasm, "\tpush dword 1\n");
  fprintf(fpasm, "fin_mayor%d:\n", etiqueta);
}


//EXAMEN 2013
void mas_igual(FILE *fpasm, char *nombre, int es_variable_2) {
    if (fpasm == NULL) return;

    fprintf(fpasm, "\n\t; Mas_igual\n");

    /* Pop both operands */
    fprintf(fpasm, "\tmov dword eax, [_%s]\n", nombre);
    fprintf(fpasm, "\tpop dword edx\n"); // eax : x, edx : 8

    //fprintf(fpasm, "\tmov dword eax, [eax]\n");
    if (es_variable_2 == 1) fprintf(fpasm, "\tmov dword edx, [edx]\n");

    fprintf(fpasm, "\tadd eax, edx\n"
                   "\tpush dword eax\n");
}

//EXAMEN ENERO 2021/2022

void do_while_inicio(FILE *fpasm, int etiqueta) {

    /* Error control */
    if (fpasm == NULL || etiqueta < 0) return;

    /* Print start label */
    fprintf(fpasm, "\n\t; Inicio de do_while\n");
    fprintf(fpasm, "do_while%d:\n", etiqueta);
}

void do_while_exp_pila(FILE *fpasm, int exp_es_variable, int etiqueta) {

    /* Error control */
    if (fpasm == NULL || exp_es_variable < 0 || exp_es_variable > 1 || etiqueta < 0)
        return;

    /* Pop result of the comparison from stack */
    fprintf(fpasm, "\n\t; Comprobar condicion de do_while\n");
    fprintf(fpasm, "\tpop dword eax\n");
    if (exp_es_variable == 1) fprintf(fpasm, "\tmov dword eax, [eax]\n");
    
    /* If the comparison is false, jump to the end */
    fprintf(fpasm, "\tcmp eax, 0\n"
                   "\tje near end_do_while%d\n", etiqueta);
}

void do_while_fin(FILE *fpasm, int etiqueta) {
    /* Error control */
    if (fpasm == NULL || etiqueta < 0) return;

    /* Loop back */
    fprintf(fpasm, "\tjmp near do_while%d\n", etiqueta);
    
    /* Print end label */
    fprintf(fpasm, "\n\t; Fin de do_while\n");
    fprintf(fpasm, "end_do_while%d:\n", etiqueta);
}

void leer(FILE *fpasm, char *nombre, int tipo)
{
  if (fpasm == NULL || !nombre)
  {
    fprintf(stderr, "leer\n");
    return;
  }

  fprintf(fpasm, "\tpush dword _%s\n", nombre);
  if (tipo == BOOLEANO)
    fprintf(fpasm, "\tcall scan_boolean\n");
  else
    fprintf(fpasm, "\tcall scan_int\n");

  fprintf(fpasm, "\tadd esp, 4\n");
}

void escribir(FILE *fpasm, int es_variable, int tipo)
{
  if (fpasm == NULL || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "escribir\n");
    return;
  }
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable)
  {
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
    fprintf(fpasm, "\tpush dword eax\n");
  }
  else
    fprintf(fpasm, "\tpush dword eax\n");

  if (tipo == BOOLEANO)
    fprintf(fpasm, "\tcall print_boolean\n");
  else
    fprintf(fpasm, "\tcall print_int\n");

  fprintf(fpasm, "\tadd dword esp, 4\n");
  fprintf(fpasm, "\tcall print_endofline\n");
}

void escribir_operando(FILE *fpasm, char *nombre, int es_variable)
{
  if (fpasm == NULL || !nombre || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "escribir_operando\n");
    return;
  }
  if (es_variable)
    fprintf(fpasm, "\tpush dword _%s\n", nombre);
  else
    fprintf(fpasm, "\tpush dword %s\n", nombre);
}

void escribirParametro(FILE *fpasm, int pos_parametro, int num_total_parametros)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "escribirParametro\n");
    return;
  }

  int aux = 4 * (1 + (num_total_parametros - pos_parametro));
  fprintf(fpasm, "\tlea eax, [ebp + %d]\n", aux); //muy similar a lo que hacemos en variable local
  fprintf(fpasm, "\tpush dword eax\n");
}

void escribirVariableLocal(FILE *fpasm, int posicion_variable_local)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "escribirVariableLocal\n");
    return;
  }

  int auxiliar = 4 * posicion_variable_local;          //calculamos la posicion que tenemos que tener para estar en el top de la pila
  fprintf(fpasm, "\tlea eax, [ebp - %d]\n", auxiliar); //esto del lea no sé si estaría bien, creo que si
  fprintf(fpasm, "\tpush dword eax\n");                //guardamos nuestra variable local a usar luego en donde haga falta a través de la pila
}

void declararFuncion(FILE *fpasm, char *nombre_funcion, int num_var_loc)
{
  if (fpasm == NULL || !nombre_funcion)
  {
    fprintf(stderr, "declararFuncion\n");
    return;
  }
  fprintf(fpasm, "_%s:\n", nombre_funcion);
  fprintf(fpasm, "\tpush ebp\n");
  fprintf(fpasm, "\tmov ebp, esp\n");
  fprintf(fpasm, "\tsub esp, %d\n", 4 * num_var_loc);
}

void ifthenelse_inicio(FILE *fpasm, int exp_es_variable, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "ifthenelse_inicio\n");
    return;
  }

  fprintf(fpasm, "\tpop eax\n");
  if (exp_es_variable)
    fprintf(fpasm, "\tmov eax, [eax]\n");

  fprintf(fpasm, "\tcmp eax, 0\n");
  fprintf(fpasm, "\tje fin_then%d\n", etiqueta);
}

void ifthen_inicio(FILE *fpasm, int exp_es_variable, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "ifthen_inicio\n");
    return;
  }
  fprintf(fpasm, "\tpop eax\n");
  if (exp_es_variable)
    fprintf(fpasm, "\tmov eax, [eax]\n");

  fprintf(fpasm, "\tcmp eax, 0\n");
  fprintf(fpasm, "\tje fin_then%d\n", etiqueta);
}

void ifthen_fin(FILE *fpasm, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "ifthen_fin\n");
    return;
  }

  fprintf(fpasm, "fin_then%d:\n", etiqueta);
}

void ifthenelse_fin_then(FILE *fpasm, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "ifthenelse_fin_then\n");
    return;
  }
  fprintf(fpasm, "\tjmp near fin_ifelse%d\n", etiqueta);
  fprintf(fpasm, "fin_then%d:\n", etiqueta);
}

void ifthenelse_fin(FILE *fpasm, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "ifthenelse_fin\n");
    return;
  }

  fprintf(fpasm, "fin_ifelse%d:\n", etiqueta);
}

void while_inicio(FILE *fpasm, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "while_inicio\n");
    return;
  }

  fprintf(fpasm, "inicio_while%d:\n", etiqueta);
}

void while_exp_pila(FILE *fpasm, int exp_es_variable, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "while_exp_pila\n");
    return;
  }
  fprintf(fpasm, "\tpop eax\n");

  if (exp_es_variable > 0)
    fprintf(fpasm, "\tmov eax, [eax]\n");

  fprintf(fpasm, "cmp eax, 0\n");
  fprintf(fpasm, "\tje fin_while%d\n", etiqueta);
}

void while_fin(FILE *fpasm, int etiqueta)
{
  if (fpasm == NULL)
  {
    fprintf(stderr, "while_fin\n");
    return;
  }

  fprintf(fpasm, "\tjmp near inicio_while%d\n", etiqueta);
  fprintf(fpasm, "fin_while%d:\n", etiqueta);
}

void escribir_elemento_vector(FILE *fpasm, char *nombre_vector, int tam_max, int exp_is_dir)
{
  if (!fpasm || !nombre_vector)
  {
    fprintf(stderr, "escribir_elemento_vector\n");
    return;
  }

  fprintf(fpasm, "\tpop dword eax\n");
  if (exp_is_dir == 1)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  
  fprintf(fpasm, "\tcmp eax, 0\n");
  fprintf(fpasm, "\tjl near fin_indice_fuera_rango\n");
  fprintf(fpasm, "\tcmp eax, %d\n", tam_max - 1);
  fprintf(fpasm, "\tjg near fin_indice_fuera_rango\n");
  fprintf(fpasm, "\tmov dword edx, _%s\n", nombre_vector);
  fprintf(fpasm, "\tlea eax, [edx + eax*4]\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void asignarDestinoEnPila(FILE *fpasm, int es_variable)
{
  if (fpasm == NULL || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "asignarDestinoEnPila\n");
    return;
  }

  fprintf(fpasm, "\tpop dword ebx\n");
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_variable)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  fprintf(fpasm, "\tmov dword [ebx], eax\n");
}

void llamarFuncion(FILE *fpasm, char *nombre_funcion, int num_argumentos)
{
  if (fpasm == NULL || !nombre_funcion)
  {
    fprintf(stderr, "llamarFuncion\n");
    return;
  }
  fprintf(fpasm, "\tcall _%s\n", nombre_funcion);
}

void retornarFuncion(FILE *fpasm, int es_variable)
{
  if (fpasm == NULL || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "retornarFuncion\n");
    return;
  }
  fprintf(fpasm, "\tpop eax\n");

  if (es_variable)
    fprintf(fpasm, "\tmov dword eax, [eax]\n");

  fprintf(fpasm, "\tmov esp, ebp\n");
  fprintf(fpasm, "\tpop ebp\n");
  fprintf(fpasm, "\tret\n");
}

void operandoEnPilaAArgumento(FILE *fpasm, int es_variable)
{
  if (fpasm == NULL || (es_variable != 0 && es_variable != 1))
  {
    fprintf(stderr, "operandoEnPilaAArgumento\n");
    return;
  }

  if (es_variable)
  {
    fprintf(fpasm, "\tpop eax\n");
    fprintf(fpasm, "\tmov eax, [eax]\n");
    fprintf(fpasm, "\tpush eax\n");
  }
}

void limpiarPila(FILE *fpasm, int num_argumentos)
{
  if (fpasm == NULL || num_argumentos < 0)
  {
    fprintf(stderr, "limpiarPila\n");
    return;
  }

  fprintf(fpasm, "\tadd esp, %d\n", num_argumentos * 4);
  fprintf(fpasm, "\tpush dword eax\n");
}
