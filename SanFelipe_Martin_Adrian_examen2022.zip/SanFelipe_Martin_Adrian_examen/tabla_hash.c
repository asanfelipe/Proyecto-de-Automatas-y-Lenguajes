#include "tabla_hash.h"

struct _NODO
{
	char *key;
	SIMBOLO value;
	struct _NODO *next;
};

struct _TABLA_HASH
{
	int size;
	struct _NODO **table;
};

SIMBOLO *nuevo_simbolo(char *identificador, int symbol, int tipo, int categoria, int valor, int longitud, int num_parametros, int posicion, int num_loc)
{
	SIMBOLO *new;
	new = calloc(1, sizeof(SIMBOLO));
	strcpy(new->identificador, identificador);
	new->symbol = symbol;
	new->tipo = tipo;
	new->categoria = categoria;
	new->valor = valor;
	new->longitud = longitud;
	new->num_parametros = num_parametros;
	new->posicion = posicion;
	new->num_loc = num_loc;
	return new;
}

TABLA_HASH *tablahash_init(int size)
{

	TABLA_HASH *hashtable = NULL;
	int i;
	if (size < 1)
		return NULL;

	if ((hashtable = malloc(sizeof(TABLA_HASH))) == NULL)
		return NULL;

	if ((hashtable->table = malloc(sizeof(NODO *) * size)) == NULL)
		return NULL;
	
	for (i = 0; i < size; i++)
		hashtable->table[i] = NULL;
	
	hashtable->size = size;

	return hashtable;
}

int tablahash_hash(TABLA_HASH *hashtable, char *key)
{

	unsigned long int hashval = 0;
	int i = 0;

	while (hashval < ULONG_MAX && i < strlen(key))
	{
		hashval = hashval << 8;
		hashval += key[i];
		i++;
	}

	return hashval % hashtable->size;
}

NODO *tablahash_newpair(char *key, SIMBOLO *value)
{
	NODO *newpair;

	if (((newpair = malloc(sizeof(NODO))) == NULL) || ((newpair->key = strdup(key)) == NULL))
		return NULL;

	strcpy(newpair->value.identificador, value->identificador);
	newpair->value.symbol = value->symbol;
	newpair->value.tipo = value->tipo;
	newpair->value.categoria = value->categoria;
	newpair->value.valor = value->valor;
	newpair->value.longitud = value->longitud;
	newpair->value.num_parametros = value->num_parametros;
	newpair->value.posicion = value->posicion;
	newpair->value.num_loc = value->num_loc;
	newpair->next = NULL;

	return newpair;
}

int tablahash_set(TABLA_HASH *hashtable, char *key, SIMBOLO *value)
{
	int bin = 0;
	NODO *newpair = NULL;
	NODO *next = NULL;
	NODO *last = NULL;
	bin = tablahash_hash(hashtable, key);
	next = hashtable->table[bin];
	while (next != NULL && next->key != NULL && strcmp(key, next->key) > 0)
	{
		last = next;
		next = next->next;
	}

	if (next != NULL && next->key != NULL && strcmp(key, next->key) == 0)
	{
		strcpy(next->value.identificador, value->identificador);
		next->value.symbol = value->symbol;
		next->value.tipo = value->tipo;
		next->value.categoria = value->categoria;
		next->value.valor = value->valor;
		next->value.longitud = value->longitud;
		next->value.num_parametros = value->num_parametros;
		next->value.posicion = value->posicion;
		next->value.num_loc = value->num_loc;

		return 0;
	}
	else
	{
		newpair = tablahash_newpair(key, value);

		if (next == hashtable->table[bin])
		{
			newpair->next = next;
			hashtable->table[bin] = newpair;
		}
		else if (next == NULL)
		{
			last->next = newpair;
		}
		else
		{
			newpair->next = next;
			last->next = newpair;
		}

		return 0;
	}
}
SIMBOLO *tablahash_get(TABLA_HASH *hashtable, char *key)
{
	int bin = 0;
	NODO *pair;

	bin = tablahash_hash(hashtable, key);

	pair = hashtable->table[bin];
	while (pair != NULL && pair->key != NULL && strcmp(key, pair->key) > 0)

		pair = pair->next;

	if (pair == NULL || pair->key == NULL || strcmp(key, pair->key) != 0)
		return NULL;
	else
		return &pair->value;
}