/*
*******************************
* Alfa.c                      *
* Adrían Mushegyian Crespo    *
* Enmanuel De Abreu Gil       *
* Carlos Vives Gil            *
*******************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "alfa.h"

TABLAS_HASH hashtable;
FILE *yyout;

int yyparse();
int main(int argc, char **argv){

  extern FILE *yyin;
  char *entrada, *salida;

  /* comprobacion de argumentos */
  if (argc != 3)
  {
    fprintf(stderr, "Error input parametros\n");
    fprintf(stderr, "./alfa <nom_fichero_input> <nom_fichero_output>\n");
    return EXIT_FAILURE;
  }

  /* recogiendo argumentos */
  entrada = argv[1];
  fprintf(stdout, "%s\n", entrada);
  salida = argv[2];
  fprintf(stdout, "%s\n", salida);

  /* abrir ficheros */
  yyin = fopen(entrada, "r");
  if (!yyin)
    return EXIT_FAILURE;
  
  yyout = fopen(salida, "w");
  if (!yyout)
    return EXIT_FAILURE;
 
  hashtable.hash_global = tablahash_init(65536);
  hashtable.is_local = 0;

  yyparse();

  /* cerramos ficheros */
  fclose(yyin);
  fclose(yyout);

  return EXIT_SUCCESS;
}
