/*
*******************************
* Alfa.h                      *
* Adrían Mushegyian Crespo    *
* Enmanuel De Abreu Gil       *
* Carlos Vives Gil            *
*******************************
*/
#ifndef ALFA_H
#define ALFA_H
#define MAX_LONG_ID 100
#define MAX_TAMANIO_VECTOR 64

#include "generacion.h"
#include "tabla_simbolos.h"


typedef struct _tipo_atributos {
 char lex[MAX_LONG_ID+1];
 int tipo;
 int valor;
 int is_dir;
 int tag;
 char ind_lex[MAX_LONG_ID+1];
 int ind_is_dir;
} tipo_atributos;

#endif /* ALFA_H */
