/*
*******************************
* tabla_simbolos.c            *
* Adrían Mushegyian Crespo    *
* Enmanuel De Abreu Gil       *
* Carlos Vives Gil            *
*******************************
*/

#include "tabla_simbolos.h"

int cerrarAmbito(TABLAS_HASH *hashTable)
{
  if (hashTable->is_local == 0)
    return -1;
  else
  {
    free(hashTable->hash_local);
    hashTable->is_local = 0;
    return EXIT_SUCCESS;
  }
}

int insertTabla(TABLAS_HASH *hashTable, char *key, SIMBOLO *valor)
{
  int result;
  if (hashTable->is_local == 1)
  {
    result = tablahash_set(hashTable->hash_local, key, valor);
    if (result == -1)
      return EXIT_FAILURE;
    else
      return EXIT_SUCCESS;
  }
  else
  {
    result = tablahash_set(hashTable->hash_global, key, valor);

    if (result == -1)
      return EXIT_FAILURE;

    if (valor->symbol == FUNCION)
    {
      if (hashTable->is_local != 0)
        return -1;
      hashTable->is_local = 1;
      hashTable->hash_local = tablahash_init(65536);
      result = tablahash_set(hashTable->hash_local, key, valor);

      if (result == -1)
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
  }
}

SIMBOLO *findTabla(TABLAS_HASH *hashTable, char *key)
{
  SIMBOLO *result;

  if (hashTable->is_local == 1)
  {
    result = tablahash_get(hashTable->hash_local, key);
    if (result == NULL)
    {
      result = tablahash_get(hashTable->hash_global, key);
      if (result == NULL)
        return NULL;
      else
        return result;
    }
    else
      return result;
  }
  else
  {
    result = tablahash_get(hashTable->hash_global, key);
    if (result == NULL)
      return NULL;
    else
      return result;
  }
}